import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Home() {
  const [coins, setCoins] = useState([])

  useEffect(() => {
    axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: {
        vs_currency: 'usd',
        order: 'market_cap_desc',
        per_page: 5,
        page: 1,
        sparkline: false
      }
    }).then(res => setCoins(res.data))
  }, [])

  const saveToFavorites = (coin) => {
    let favs = JSON.parse(localStorage.getItem('favorites')) || []
    if (!favs.find(f => f.id === coin.id)) {
      favs.push(coin)
      localStorage.setItem('favorites', JSON.stringify(favs))
      alert(`${coin.name} saved!`)
    }
  }

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Top 5 Cryptocurrencies</h1>
      <ul>
        {coins.map(coin => (
          <li key={coin.id} className="mb-2">
            <span>{coin.name} - ${coin.current_price}</span>
            <button
              className="ml-4 text-sm bg-blue-500 text-white px-2 py-1 rounded"
              onClick={() => saveToFavorites(coin)}
            >
              Save
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
