export default function About() {
  return <div><h1 className="text-xl font-bold">About Crypto Tracker</h1><p>This is a simple SPA built with React and Vite.</p></div>
}
