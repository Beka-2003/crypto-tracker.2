import { useEffect, useState } from 'react'

export default function Favorites() {
  const [favorites, setFavorites] = useState([])

  useEffect(() => {
    const favs = JSON.parse(localStorage.getItem('favorites')) || []
    setFavorites(favs)
  }, [])

  return (
    <div>
      <h1 className="text-xl font-bold mb-4">Favorite Cryptos</h1>
      {favorites.length === 0 && <p>No favorites saved yet.</p>}
      <ul>
        {favorites.map(coin => (
          <li key={coin.id}>{coin.name} - ${coin.current_price}</li>
        ))}
      </ul>
    </div>
  )
}
